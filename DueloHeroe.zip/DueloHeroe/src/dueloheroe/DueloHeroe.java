/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dueloheroe;
import java.util.Scanner;
/**
 *
 * @author AL-Alumno
 */
public class DueloHeroe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
        Heroes heroe1 = new Heroes("Sabrina", 200, 20);
        Heroes heroe2 = new Heroes("Anays", 150, 27);
        System.out.println("Empiza atacando: ");
        System.out.println("1. Sabrina");
        System.out.println("2. Anays");
        
        while(heroe1.estaVivo() && heroe2.estaVivo()){
            int opcion = sc.nextInt();
            switch(opcion){
                    case 1: heroe1.atacar(heroe2); break;
                    case 2: heroe2.atacar(heroe1); break;
                    default: System.out.println("Opcion no encontrada");             
            }
        }
        if(heroe1.estaVivo()){
            System.out.println("Sabrina ganó");
        }else{
            System.out.println("Anays ganó");
        }            
    }
    
}
