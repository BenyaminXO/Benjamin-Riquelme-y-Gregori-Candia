/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dueloheroe;
/**
 *
 * @author AL-Alumno
 */
public class Heroes {
    String nombre;
    int vida;
    int atacar;

    public Heroes(String nombre, int vida, int atacar) {
        this.nombre = nombre;
        this.vida = vida;
        this.atacar = atacar;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getAtacar() {
        return atacar;
    }

    public void setAtacar(int atacar) {
        this.atacar = atacar;
    }

    public void atacar(Heroes rival){
        int daño = atacar;
        int critic = (int) (Math.random() * 10) + 1;
        if (critic == 4){
            daño += daño;
        }
        rival.setVida(rival.getVida() - daño);
        System.out.println(nombre + " hizo " + daño + " de daño");
        System.out.println(rival.getNombre() + " tiene " + rival.getVida() + " de vida");
    }
    public boolean estaVivo(){
        return vida > 0;
    }
    
}
