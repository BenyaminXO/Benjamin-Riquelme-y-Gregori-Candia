/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parquediversionmagica;
import java.util.Scanner;
/**
 *
 * @author AL-Alumno
 */
public class ParqueDiversionMagica{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        boolean salir = false;
        int opcion;
        boolean subir;
        Juego juegoActual;
        Juego juego1 = new Juego("Rueda de la depresion", 13, 5);
        Juego juego2 = new Juego("Montaña de la felicidad", 81, 0.5);
        Juego juego3 = new Juego("Carrera de micros de viña del mar de Chile parocinada por RedBull que te da alas", 18, 10);
        
        
        System.out.println("===MENU ATRACCIONES===");
        System.out.println("1.- " + juego1.getNombre());
        System.out.println("2.- " + juego2.getNombre());
        System.out.println("3.- " + juego3.getNombre());
        System.out.println("0.- Salir");
        while (!salir) {
            System.out.println("Ingrese una opcion");
            opcion = sc.nextInt();
            if(opcion == 0){
                salir = true;
                continue;
            }
            System.out.println("Ingrese su edad: ");
            int edad = sc.nextInt();
            switch(opcion){
                case 1: juego1.mostrarInfo(); subir = juego1.puedeSubir(edad); juegoActual = juego1;break;
                case 2: juego2.mostrarInfo(); subir = juego2.puedeSubir(edad); juegoActual = juego2; break;
                case 3: juego3.mostrarInfo(); subir = juego3.puedeSubir(edad); juegoActual = juego3; break;
                default: System.out.println("Opcion no valida"); continue;
            }
            if(subir == false){
                System.out.println("Ers muy pequeño para subirte a este juego");
                salir = true;
            }else{
                juegoActual.jugar();
            }
        } 
    }
    
}
