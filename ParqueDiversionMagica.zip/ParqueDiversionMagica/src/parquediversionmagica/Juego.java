/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parquediversionmagica;

/**
 *
 * @author AL-Alumno
 */
public class Juego {
    private String nombre;
    private int edadMinima;
    private double duracion;

    public Juego(String nombre, int edadMinima, double duracion) {
        this.nombre = nombre;
        this.edadMinima = edadMinima;
        this.duracion = duracion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdadMinima() {
        return edadMinima;
    }

    public void setEdadMinima(int edadMinima) {
        this.edadMinima = edadMinima;
    }

    public double getDuracion() {
        return duracion;
    }

    public void setDuracion(double duracion) {
        this.duracion = duracion;
    }
    
    public void jugar(){
        System.out.println("Ahora estas jugando " + this.nombre);
    }
    
    public void mostrarInfo(){
        System.out.println("====informacion del juego====");
        System.out.println("Nombre: "+ nombre);
        System.out.println("Edad minima: "+ edadMinima);
        System.out.println("Duracion: "+ duracion);
    }
    
    public boolean puedeSubir(int edad){
        if(edad < edadMinima){
            return false;
        }else{
            return true;
        }
    }
    
}
