/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mascotavirtual;
import java.util.Scanner;
/**
 *
 * @author AL-Alumno
 */
public class MascotaVirtual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int opcion;
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingresa el nombre de tu mascota >W<: ");
        String nombre = sc.nextLine();
        
        Mascota mascota1 = new Mascota(nombre);
        do{
            System.out.println("== Menu de mascota nwn ==");
            System.out.println("1. Jugar");
            System.out.println("2. Comer");
            System.out.println("3. Dormir");
            System.out.println("4. Ver estado");
            System.out.println("5. Salir");
            
            opcion = sc.nextInt();
            
            switch (opcion){
                case 1: 
                    mascota1.jugar();
                    break;
                case 2:
                    mascota1.comer();
                    break;
                case 3: 
                    mascota1.dormir();
                    break;
                case 4: 
                    mascota1.mostrarEstado();
                    break;
                case 5:
                    System.out.println("Nos vemos humano :b");
                    break;
            }
        } while (opcion != 5);
        
        sc.close();
    }
    
}
