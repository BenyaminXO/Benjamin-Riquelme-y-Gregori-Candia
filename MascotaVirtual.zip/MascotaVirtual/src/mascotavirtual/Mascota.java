/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mascotavirtual;

/**
 *
 * @author AL-Alumno
 */
public class Mascota {
    private String nombre;
    private int energia;
    private int hambre;

    public Mascota(String nombre) {
        this.nombre = nombre;
        this.energia = 100;
        this.hambre = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEnergia() {
        return energia;
    }

    public void setEnergia(int energia) {
        this.energia = energia;
    }

    public int getHambre() {
        return hambre;
    }

    public void setHambre(int hambre) {
        this.hambre = hambre;
    }
    
    public void comer(){
        hambre = hambre - 30;
        if (hambre < 0 ){
            setHambre(0);
        }
        System.out.println("Tu mascota comio exitosamente :D");
    }
    
    public void jugar(){
        if (energia <= 0 ){
            System.out.println("Energia insuficiente, no puedes jugar :c");
            return;
        }   
        energia = energia - 20;
        hambre = hambre + 15;
        if (energia < 0 ){
            setEnergia(0);
        }
        System.out.println("Estas jugando con tu mascota owo");
    }
    
    public void dormir(){
        if (energia == 100 ){
            System.out.println("Energia al maximo o.o");
            return;
        }
        setEnergia(100);
        System.out.println("Tu mascota ha descansado exitosamente c:");
    }
    
    public boolean estaFeliz(){
        if (energia > 50 && hambre < 50){
            return true;
        }else{
            return false;
        }
    }
    
    public void mostrarEstado(){
        if (estaFeliz()){
            System.out.println("Tu mascota esta muy contenta :3");
        }else{
            System.out.println("Tu mascota no esta feliz unu");
        }
    }
}
