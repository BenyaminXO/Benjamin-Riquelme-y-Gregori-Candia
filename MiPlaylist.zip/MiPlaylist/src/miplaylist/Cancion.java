/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package miplaylist;

/**
 *
 * @author AL-Alumno
 */
public class Cancion {
    String titulo;
    String artista;
    int duracionSeg;

    public Cancion(String titulo, String artista, int duracionSeg) {
        this.titulo = titulo;
        this.artista = artista;
        this.duracionSeg = duracionSeg;
    }    
    public Cancion() {
        this.titulo = "Backwards";
        this.artista = "The rare ocasions";
        this.duracionSeg = 160;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public int getDuracionSeg() {
        return duracionSeg;
    }

    public void setDuracionSeg(int duracionSeg) {
        this.duracionSeg = duracionSeg;
    }
    
    public boolean esLarga(){
        return duracionSeg > 240;
    }
    
    public String duracionFormato(){
        int num1;
        int num2;
        num1 = duracionSeg / 60;
        num2 = duracionSeg % 60;
        return num1 + ":" + num2;
    }
    
    public void mostrar(){
        String coso;
        if (esLarga()){
            coso = "larga";
        }else{
            coso = "normal";
        }
        System.out.println(titulo + " - " + artista + " (" + duracionFormato() + ") ("+coso+")");
    }
}
