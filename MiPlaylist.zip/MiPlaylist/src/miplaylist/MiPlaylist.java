/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package miplaylist;
/**
 *
 * @author AL-Alumno
 */
public class MiPlaylist {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Cancion cancion1 = new Cancion("La vaca lola", "La granja de cenon", 137);
        Cancion cancion2 = new Cancion("Promise", "Laufey", 235);
        Cancion cancion3 = new Cancion("Tus vueltas", "Milo j", 250);
        
        System.out.println("Top 3 canciones");
        System.out.println("1.- "+cancion1.getTitulo());
        System.out.println("2.- "+cancion2.getTitulo());
        System.out.println("3.- "+cancion3.getTitulo());
        cancion1.setDuracionSeg(340);
        System.out.println("Nueva duracion de "+cancion1.getTitulo()+ ": "+cancion1.getDuracionSeg());
    }
    
}
